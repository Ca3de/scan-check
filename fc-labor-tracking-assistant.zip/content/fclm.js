// FC Labor Tracking Assistant - FCLM Portal Content Script
// Fetches individual employee time details on demand

(function() {
  'use strict';

  console.log('[FC Labor Tracking] FCLM content script loaded');

  // ============== CONFIGURATION ==============
  const CONFIG = {
    WAREHOUSE_ID: new URLSearchParams(window.location.search).get('warehouseId') || 'IND8',
    TIMEZONE: 'America/Indiana/Indianapolis',
    // Night shift times
    SHIFT_START_HOUR: 18,  // 6 PM
    SHIFT_END_HOUR: 6      // 6 AM next day
  };

  // ============== HELPERS ==============

  function log(message, type = 'info') {
    const prefix = '[FC Labor Tracking FCLM]';
    const timestamp = new Date().toLocaleTimeString();
    const styles = {
      info: 'color: #3b82f6',
      success: 'color: #22c55e',
      error: 'color: #ef4444',
      warn: 'color: #f59e0b'
    };
    console.log(`%c${prefix} [${timestamp}] ${message}`, styles[type] || styles.info);
  }

  // Calculate shift date range based on current time (for night shift)
  function getShiftDateRange() {
    const now = new Date();
    const currentHour = now.getHours();

    let startDate, endDate;

    if (currentHour >= CONFIG.SHIFT_START_HOUR) {
      // Between 6PM-11:59PM: shift started today, ends tomorrow
      startDate = new Date(now);
      endDate = new Date(now);
      endDate.setDate(endDate.getDate() + 1);
    } else if (currentHour < CONFIG.SHIFT_END_HOUR) {
      // Between 12AM-6AM: shift started yesterday, ends today
      startDate = new Date(now);
      startDate.setDate(startDate.getDate() - 1);
      endDate = new Date(now);
    } else {
      // Between 6AM-6PM: use today as day shift or previous night
      // Default to checking previous night shift
      startDate = new Date(now);
      startDate.setDate(startDate.getDate() - 1);
      endDate = new Date(now);
    }

    const formatDate = (d) => {
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${year}/${month}/${day}`;
    };

    return {
      startDate: formatDate(startDate),
      endDate: formatDate(endDate),
      startHour: CONFIG.SHIFT_START_HOUR,
      endHour: CONFIG.SHIFT_END_HOUR
    };
  }

  // ============== FETCH EMPLOYEE TIME DETAILS ==============

  // Build the URL for employee time details
  function buildTimeDetailsUrl(employeeId) {
    const shiftRange = getShiftDateRange();

    const params = new URLSearchParams({
      employeeId: employeeId,
      warehouseId: CONFIG.WAREHOUSE_ID,
      startDateDay: shiftRange.endDate,
      maxIntradayDays: '1',
      spanType: 'Intraday',
      startDateIntraday: shiftRange.startDate,
      startHourIntraday: String(shiftRange.startHour),
      startMinuteIntraday: '0',
      endDateIntraday: shiftRange.endDate,
      endHourIntraday: String(shiftRange.endHour),
      endMinuteIntraday: '0'
    });

    return `https://fclm-portal.amazon.com/employee/timeDetails?&${params.toString()}`;
  }

  async function fetchEmployeeTimeDetails(employeeId) {
    log(`Fetching time details for employee: ${employeeId}`);

    const shiftRange = getShiftDateRange();
    log(`Shift range: ${shiftRange.startDate} ${shiftRange.startHour}:00 to ${shiftRange.endDate} ${shiftRange.endHour}:00`);

    const url = buildTimeDetailsUrl(employeeId);
    log(`Target URL: ${url}`);

    // Check if we're already on the CORRECT employee's timeDetails page
    const currentUrl = window.location.href;
    const isOnTimeDetailsPage = currentUrl.includes('/employee/timeDetails');
    const isCorrectEmployee = currentUrl.includes(`employeeId=${employeeId}`);

    if (isOnTimeDetailsPage && isCorrectEmployee) {
      log(`Already on timeDetails page for employee ${employeeId}, scraping live DOM...`);
      return scrapeTimeDetailsFromLiveDOM(employeeId);
    }

    // Need to navigate to the correct employee's page
    log(`Navigating to timeDetails page for employee ${employeeId}...`);

    // Store the request in sessionStorage so we can complete it after navigation
    sessionStorage.setItem('fc_pending_lookup', JSON.stringify({
      employeeId,
      timestamp: Date.now()
    }));

    // Navigate to the time details page
    window.location.href = url;

    // Return a pending response - the actual data will be sent after page loads
    return {
      employeeId,
      sessions: [],
      pending: true,
      message: 'Navigating to time details page...'
    };
  }

  // Scrape time details from the live DOM (after JavaScript has rendered)
  function scrapeTimeDetailsFromLiveDOM(employeeId) {
    log('Scraping time details from live DOM...');

    const result = {
      employeeId: employeeId,
      sessions: [],
      currentActivity: null,
      totalHours: 0,
      isClockedIn: false
    };

    // Target the specific FCLM time details table using its unique selector
    const targetTable = document.querySelector('table.ganttChart[aria-label="Time Details"]');

    if (!targetTable) {
      log('Could not find table.ganttChart[aria-label="Time Details"]', 'warn');
      // Fallback: try to find any table with ganttChart class
      const fallbackTable = document.querySelector('table.ganttChart');
      if (fallbackTable) {
        log('Found fallback table.ganttChart', 'info');
        return scrapeGanttTable(fallbackTable, employeeId, result);
      }
      log('No ganttChart table found at all', 'error');
      return result;
    }

    log('Found time details table: table.ganttChart[aria-label="Time Details"]', 'success');
    return scrapeGanttTable(targetTable, employeeId, result);
  }

  // Parse the FCLM gantt chart table structure
  function scrapeGanttTable(table, employeeId, result) {
    // Get all rows from tbody (skip thead which has summary and header rows)
    const tbody = table.querySelector('tbody');
    const rows = tbody ? tbody.querySelectorAll('tr') : table.querySelectorAll('tr');

    log(`Found ${rows.length} rows in table`);

    for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
      const row = rows[rowIdx];
      const rowClass = row.className || '';

      // Skip rows that aren't data rows (header rows, summary rows)
      if (rowClass.includes('totSummary') || row.querySelector('th')) {
        continue;
      }

      // Determine row type and parse accordingly
      // Row types: clock-seg, function-seg, job-seg
      const cells = row.querySelectorAll('td');
      if (cells.length < 4) continue;

      let title = '';
      let start = '';
      let end = '';
      let duration = '';

      if (rowClass.includes('job-seg')) {
        // Job segment rows have: [trackingType] [title (in <a>)] [start] [end] [duration]
        // Cell 0: trackingType (e.g., "m")
        // Cell 1: title with <a> link containing job name
        // Cell 2: start time
        // Cell 3: end time
        // Cell 4: duration
        const titleLink = cells[1]?.querySelector('a');
        title = titleLink ? titleLink.textContent.trim() : cells[1]?.textContent?.trim() || '';
        start = cells[2]?.textContent?.trim() || '';
        end = cells[3]?.textContent?.trim() || '';
        duration = cells[4]?.textContent?.trim() || '';

        log(`[job-seg] Row ${rowIdx}: ${title} | ${start} | ${end} | ${duration}`);

      } else if (rowClass.includes('function-seg') || rowClass.includes('clock-seg')) {
        // Function/Clock segment rows have: [title colspan=2] [start] [end] [duration]
        // The title cell spans 2 columns, so indices shift:
        // Cell 0: title (colspan="2", may contain ♦ separator like "C-Returns Support♦C-Returns_StowSweep")
        // Cell 1: start time
        // Cell 2: end time
        // Cell 3: duration
        let rawTitle = cells[0]?.textContent?.trim() || '';

        // Handle diamond separator (♦ or &diams;) - extract the path name after it
        if (rawTitle.includes('♦')) {
          const parts = rawTitle.split('♦');
          title = parts[parts.length - 1].trim(); // Get the path name (last part)
        } else {
          title = rawTitle;
        }

        start = cells[1]?.textContent?.trim() || '';
        end = cells[2]?.textContent?.trim() || '';
        duration = cells[3]?.textContent?.trim() || '';

        log(`[${rowClass.includes('function-seg') ? 'function-seg' : 'clock-seg'}] Row ${rowIdx}: ${title} | ${start} | ${end} | ${duration}`);

      } else {
        // Unknown row type - try generic parsing
        // Assume: [title] [start] [end] [duration] or [title colspan=2] [start] [end] [duration]
        const firstCell = cells[0];
        const colspan = firstCell?.getAttribute('colspan');

        if (colspan === '2') {
          title = firstCell?.textContent?.trim() || '';
          start = cells[1]?.textContent?.trim() || '';
          end = cells[2]?.textContent?.trim() || '';
          duration = cells[3]?.textContent?.trim() || '';
        } else {
          // Check if first cell looks like trackingType (single char like "m")
          const firstText = firstCell?.textContent?.trim() || '';
          if (firstText.length <= 2 && cells.length >= 5) {
            // Likely job-seg style
            const titleLink = cells[1]?.querySelector('a');
            title = titleLink ? titleLink.textContent.trim() : cells[1]?.textContent?.trim() || '';
            start = cells[2]?.textContent?.trim() || '';
            end = cells[3]?.textContent?.trim() || '';
            duration = cells[4]?.textContent?.trim() || '';
          } else {
            title = firstText;
            start = cells[1]?.textContent?.trim() || '';
            end = cells[2]?.textContent?.trim() || '';
            duration = cells[3]?.textContent?.trim() || '';
          }
        }
        log(`[unknown] Row ${rowIdx}: ${title} | ${start} | ${end} | ${duration}`);
      }

      // Skip empty titles or clock entries (OnClock/OffClock are not work activities)
      if (!title || title.includes('OffClock') || title.includes('OnClock')) {
        continue;
      }

      // IMPORTANT: For MPV time calculation, only count job-seg rows
      // function-seg rows show aggregate time that OVERLAPS with job-seg rows
      // job-seg rows are the actual individual work sessions
      // Counting both would double-count the time!
      if (rowClass.includes('function-seg')) {
        log(`Skipping function-seg row for MPV (overlaps with job-seg): ${title} - ${duration}`);
        continue;
      }

      // Parse duration - FCLM uses MM:SS format (e.g., "210:35" = 210 mins 35 secs)
      const durationMinutes = parseDurationToMinutes(duration);

      const session = {
        title,
        start,
        end,
        duration,
        durationMinutes,
        rowType: rowClass.includes('job-seg') ? 'job' : 'other'
      };

      result.sessions.push(session);
      log(`Parsed session: ${title} - ${duration} (${durationMinutes} mins)`, 'success');

      // Track current activity (no end time = ongoing)
      if (!end || end === '') {
        result.currentActivity = session;
        result.isClockedIn = true;
      }
    }

    // Try to find "Hours on Task" from the page
    const pageText = document.body.textContent || '';
    const hoursMatch = pageText.match(/Hours on Task:\s*([\d.]+)\s*\/\s*([\d.]+)/);
    if (hoursMatch) {
      result.hoursOnTask = parseFloat(hoursMatch[1]);
      result.totalScheduledHours = parseFloat(hoursMatch[2]);
    }

    log(`Scraped ${result.sessions.length} sessions from live DOM`, 'success');
    return result;
  }

  // Check if we arrived here from a lookup navigation
  function checkPendingLookup() {
    const pendingStr = sessionStorage.getItem('fc_pending_lookup');
    if (pendingStr && window.location.href.includes('/employee/timeDetails')) {
      sessionStorage.removeItem('fc_pending_lookup');

      const pending = JSON.parse(pendingStr);
      const age = Date.now() - pending.timestamp;

      // Only process if the request is recent (within 30 seconds)
      if (age < 30000) {
        log(`Processing pending lookup for ${pending.employeeId} (${age}ms old)`);

        // Wait for the page to fully render
        setTimeout(() => {
          const result = scrapeTimeDetailsFromLiveDOM(pending.employeeId);

          // Send the result back to the kiosk via background script
          browser.runtime.sendMessage({
            action: 'forwardToKiosk',
            payload: {
              action: 'timeDetailsResult',
              data: result
            }
          }).catch(err => {
            log(`Error sending result to kiosk: ${err.message}`, 'error');
          });
        }, 1500); // Wait 1.5s for JavaScript to render the table
      }
    }
  }

  function parseTimeDetailsHtml(html, employeeId) {
    // Create a DOM parser to extract data from the HTML
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    const result = {
      employeeId: employeeId,
      sessions: [],
      currentActivity: null,
      totalHours: 0,
      isClockedIn: false
    };

    // Target the specific FCLM time details table using its unique selector
    const targetTable = doc.querySelector('table.ganttChart[aria-label="Time Details"]') ||
                        doc.querySelector('table.ganttChart');

    if (!targetTable) {
      log('No ganttChart table found in parsed HTML', 'warn');
      return result;
    }

    log('Found ganttChart table in parsed HTML', 'success');

    // Use the same parsing logic as scrapeGanttTable
    const tbody = targetTable.querySelector('tbody');
    const rows = tbody ? tbody.querySelectorAll('tr') : targetTable.querySelectorAll('tr');

    log(`Found ${rows.length} rows in parsed table`);

    for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
      const row = rows[rowIdx];
      const rowClass = row.className || '';

      // Skip non-data rows
      if (rowClass.includes('totSummary') || row.querySelector('th')) {
        continue;
      }

      const cells = row.querySelectorAll('td');
      if (cells.length < 4) continue;

      let title = '';
      let start = '';
      let end = '';
      let duration = '';

      if (rowClass.includes('job-seg')) {
        // Job segment: [trackingType] [title in <a>] [start] [end] [duration]
        const titleLink = cells[1]?.querySelector('a');
        title = titleLink ? titleLink.textContent.trim() : cells[1]?.textContent?.trim() || '';
        start = cells[2]?.textContent?.trim() || '';
        end = cells[3]?.textContent?.trim() || '';
        duration = cells[4]?.textContent?.trim() || '';
      } else if (rowClass.includes('function-seg') || rowClass.includes('clock-seg')) {
        // Function/Clock segment: [title colspan=2] [start] [end] [duration]
        let rawTitle = cells[0]?.textContent?.trim() || '';
        if (rawTitle.includes('♦')) {
          const parts = rawTitle.split('♦');
          title = parts[parts.length - 1].trim();
        } else {
          title = rawTitle;
        }
        start = cells[1]?.textContent?.trim() || '';
        end = cells[2]?.textContent?.trim() || '';
        duration = cells[3]?.textContent?.trim() || '';
      } else {
        // Generic fallback
        const firstCell = cells[0];
        const colspan = firstCell?.getAttribute('colspan');
        if (colspan === '2') {
          title = firstCell?.textContent?.trim() || '';
          start = cells[1]?.textContent?.trim() || '';
          end = cells[2]?.textContent?.trim() || '';
          duration = cells[3]?.textContent?.trim() || '';
        } else {
          const firstText = firstCell?.textContent?.trim() || '';
          if (firstText.length <= 2 && cells.length >= 5) {
            const titleLink = cells[1]?.querySelector('a');
            title = titleLink ? titleLink.textContent.trim() : cells[1]?.textContent?.trim() || '';
            start = cells[2]?.textContent?.trim() || '';
            end = cells[3]?.textContent?.trim() || '';
            duration = cells[4]?.textContent?.trim() || '';
          } else {
            title = firstText;
            start = cells[1]?.textContent?.trim() || '';
            end = cells[2]?.textContent?.trim() || '';
            duration = cells[3]?.textContent?.trim() || '';
          }
        }
      }

      // Skip empty or clock entries
      if (!title || title.includes('OffClock') || title.includes('OnClock')) {
        continue;
      }

      // IMPORTANT: For MPV time calculation, only count job-seg rows
      // function-seg rows show aggregate time that OVERLAPS with job-seg rows
      if (rowClass.includes('function-seg')) {
        log(`Skipping function-seg row for MPV (overlaps with job-seg): ${title} - ${duration}`);
        continue;
      }

      const durationMinutes = parseDurationToMinutes(duration);

      const session = {
        title,
        start,
        end,
        duration,
        durationMinutes,
        rowType: rowClass.includes('job-seg') ? 'job' : 'other'
      };

      result.sessions.push(session);
      log(`Parsed session: ${title} - ${duration} (${durationMinutes} mins)`);

      if (!end || end === '') {
        result.currentActivity = session;
        result.isClockedIn = true;
      }
    }

    log(`Total sessions parsed: ${result.sessions.length}`);

    // Calculate total hours from OnClock/Paid entries
    result.sessions.forEach(session => {
      if (session.title.includes('OnClock/Paid')) {
        result.totalHours += session.durationMinutes / 60;
      }
    });

    // Try to find "Hours on Task" from the page
    const hoursMatch = html.match(/Hours on Task:\s*([\d.]+)\s*\/\s*([\d.]+)/);
    if (hoursMatch) {
      result.hoursOnTask = parseFloat(hoursMatch[1]);
      result.totalScheduledHours = parseFloat(hoursMatch[2]);
    }

    log(`Parsed ${result.sessions.length} sessions for ${employeeId}`, 'success');
    return result;
  }

  function parseDurationToMinutes(duration) {
    // Duration format: "45:00" (mm:ss) or "259:00" (mmm:ss)
    if (!duration) return 0;

    const parts = duration.split(':');
    if (parts.length >= 2) {
      const minutes = parseInt(parts[0]) || 0;
      const seconds = parseInt(parts[1]) || 0;
      return minutes + (seconds / 60);
    }
    return 0;
  }

  function isOngoing(endTime) {
    // Check if the end time indicates an ongoing session
    if (!endTime || endTime === '') return true;

    // If end time contains a future date/time, it's ongoing
    // This is a simplified check - you may need to adjust based on actual format
    return false;
  }

  // ============== MESSAGE HANDLING ==============

  browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    log(`Received message: ${message.action}`);

    if (message.action === 'fetchEmployeeTimeDetails') {
      const employeeId = message.employeeId;

      fetchEmployeeTimeDetails(employeeId)
        .then(data => {
          sendResponse({ success: true, data });
        })
        .catch(error => {
          sendResponse({ success: false, error: error.message });
        });

      return true; // Async response
    }

    if (message.action === 'getConfig') {
      sendResponse({
        success: true,
        config: CONFIG
      });
      return false;
    }

    if (message.action === 'ping') {
      sendResponse({ success: true, ready: true });
      return false;
    }
  });

  // ============== UI INDICATOR ==============

  function createStatusIndicator() {
    const indicator = document.createElement('div');
    indicator.id = 'fc-fclm-status';
    indicator.innerHTML = `
      <div class="fc-fclm-status-inner">
        <span class="fc-fclm-dot"></span>
        <span class="fc-fclm-text">FCLM Ready</span>
      </div>
    `;

    const styles = document.createElement('style');
    styles.textContent = `
      #fc-fclm-status {
        position: fixed;
        bottom: 20px;
        left: 20px;
        background: #1a1a2e;
        color: #fff;
        padding: 8px 12px;
        border-radius: 6px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 12px;
        z-index: 999999;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      }
      .fc-fclm-status-inner {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .fc-fclm-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #2ecc71;
        box-shadow: 0 0 6px #2ecc71;
      }
    `;

    document.head.appendChild(styles);
    document.body.appendChild(indicator);

    return indicator;
  }

  // ============== START ==============

  // Notify background script that FCLM page is ready
  browser.runtime.sendMessage({
    action: 'contentScriptReady',
    pageType: 'fclm',
    url: window.location.href,
    warehouseId: CONFIG.WAREHOUSE_ID
  }).catch(err => {
    log(`Could not notify background: ${err.message}`, 'warn');
  });

  // Create status indicator
  createStatusIndicator();

  log('='.repeat(50));
  log('FCLM Ready for employee lookups!', 'success');
  log(`Warehouse: ${CONFIG.WAREHOUSE_ID}`);
  log(`Current URL: ${window.location.href}`);
  log('='.repeat(50));

  // Check if we arrived here from a pending lookup (after navigation)
  // Wait a bit for the page to render before checking
  setTimeout(() => {
    checkPendingLookup();
  }, 2000);

})();
